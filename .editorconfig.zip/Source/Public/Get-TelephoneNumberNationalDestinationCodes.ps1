function Get-TelephoneNumberNationalDestinationCode {
    [CmdletBinding()]
    param (
        [Parameter(ParameterSetName = "ByISO", Mandatory = $true)]
        [string]$ISO,
        [Parameter(ParameterSetName = "ByCode", Mandatory = $true)]
        [string]$Code
    )
    if ( $ISO ) {
        $CountryCodes = [CountryCode]::GetCountryCodeByISO($ISO)
    } else {
        $CountryCodes = [CountryCode]::GetCountryCodeByCode($Code)
    }
    
    $NationalDestinationCodes = @()
    foreach ($CountryCode in $CountryCodes) {
        $NDCs = [NationalDestinationCode]::GetByCountryCode($CountryCode)
        $NationalDestinationCodes += $NDCs
    }   
    return $NationalDestinationCodes
}       